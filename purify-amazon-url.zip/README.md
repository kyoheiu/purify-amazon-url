# purify-amazon-url

An extention for Firefox that purify Amazon URL.

## example
```
https://www.amazon.com/Learn-You-Haskell-Great-Good-ebook-dp-B004VB3V0K/dp/B004VB3V0K/ref=mt_other?_encoding=UTF8&me=&qid=
->
https://www.amazon.com/dp/B004VB3V0K
```

## usage
Install via addons.mozilla.org and just right-click and choose "purify Amazon URL" to reload Amazon page with purified URL.
