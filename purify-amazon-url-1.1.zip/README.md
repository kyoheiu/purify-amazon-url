# purify-amazon-url

An extention for Firefox that purifies Amazon URL and reload tab.

## example
```
https://www.amazon.com/Learn-You-Haskell-Great-Good-ebook-dp-B004VB3V0K/dp/B004VB3V0K/ref=mt_other?_encoding=UTF8&me=&qid=
->
https://www.amazon.com/dp/B004VB3V0K
```

## usage
Just right-click and choose "purify Amazon URL" to reload Amazon page with purified URL.
